import pandas as pd
from sklearn.preprocessing import LabelEncoder
import category_encoders as ce

# Keep titanic.csv in the same folder as this program.
df = pd.read_csv("titanic.csv")

# Q1: Load dataset
print("Q1: First 5 Rows\n", df.head())

# Q2: Label encode Sex
df_sex = df.copy()
le_sex = LabelEncoder()
df_sex["Sex"] = le_sex.fit_transform(df_sex["Sex"])
print("\nQ2: Label Encoded Sex\n", df_sex[["Sex"]].head())
print("Sex Mapping:", dict(zip(le_sex.classes_, le_sex.transform(le_sex.classes_))))

# Q3: Label encode Embarked (fill missing values first)
df_embarked = df.copy()
df_embarked["Embarked"] = df_embarked["Embarked"].fillna(df_embarked["Embarked"].mode()[0])
le_embarked = LabelEncoder()
df_embarked["Embarked"] = le_embarked.fit_transform(df_embarked["Embarked"])
print("\nQ3: Label Encoded Embarked\n", df_embarked[["Embarked"]].head())
print("Embarked Mapping:", dict(zip(le_embarked.classes_, le_embarked.transform(le_embarked.classes_))))

# Q4: One-hot encode Embarked
df_onehot = pd.get_dummies(df, columns=["Embarked"], dtype=int)
print("\nQ4: One-Hot Encoded Embarked\n", df_onehot.head())

# Q5: One-hot encode Pclass
df_pclass = pd.get_dummies(df, columns=["Pclass"], prefix="Class", dtype=int)
print("\nQ5: One-Hot Encoded Pclass\n", df_pclass.head())

# Q6: Map Sex manually
df_map_sex = df.copy()
df_map_sex["Sex"] = df_map_sex["Sex"].map({"male": 1, "female": 0})
print("\nQ6: Mapped Sex\n", df_map_sex[["Sex"]].head())

# Q7: Map Embarked manually
df_map_embarked = df.copy()
df_map_embarked["Embarked"] = df_map_embarked["Embarked"].map({"S": 1, "C": 2, "Q": 3})
print("\nQ7: Mapped Embarked\n", df_map_embarked[["Embarked"]].head())

# Q8: Ordinal encode Pclass
df_ordinal = df.copy()
df_ordinal["Pclass"] = df_ordinal["Pclass"].map({1: 3, 2: 2, 3: 1})
print("\nQ8: Ordinal Encoded Pclass\n", df_ordinal[["Pclass"]].head())

# Q9: Binary encode Embarked
df_binary = df.copy()
df_binary["Embarked"] = df_binary["Embarked"].fillna(df_binary["Embarked"].mode()[0])
binary_encoder = ce.BinaryEncoder(cols=["Embarked"])
df_binary_encoded = binary_encoder.fit_transform(df_binary)
print("\nQ9: Binary Encoded Embarked\n", df_binary_encoded.head())

# Q10: Frequency encode Embarked
df_frequency = df.copy()
frequency = df_frequency["Embarked"].value_counts()
df_frequency["Embarked"] = df_frequency["Embarked"].map(frequency)
print("\nQ10: Frequency Encoded Embarked\n", df_frequency[["Embarked"]].head())

print("\n========== EXPERIMENT 4 COMPLETED ==========")
