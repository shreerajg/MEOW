import pandas as pd
from imblearn.under_sampling import RandomUnderSampler
from imblearn.over_sampling import RandomOverSampler

# Change the filename if your college dataset has a different name.
# Required columns: Maths, Physics, Chemistry, Result
df = pd.read_csv("student_result.csv")

print("First Five Rows:\n", df.head())

# Separate features and target
X = df[["Maths", "Physics", "Chemistry"]]
y = df["Result"]

print("\nOriginal Dataset Shape:", df.shape)
print("\nOriginal Class Distribution:\n", y.value_counts())

# Q1: UnderSampling
print("\n========== Q1: UNDERSAMPLING ==========")
under_sampler = RandomUnderSampler(random_state=42)
X_under, y_under = under_sampler.fit_resample(X, y)

df_under = pd.DataFrame(X_under, columns=X.columns)
df_under["Result"] = y_under

print("\nClass Distribution After Undersampling:\n", df_under["Result"].value_counts())
print("Shape Before:", df.shape)
print("Shape After:", df_under.shape)
print("\nUndersampled Dataset:\n", df_under.head())

# Q2: OverSampling
print("\n========== Q2: OVERSAMPLING ==========")
over_sampler = RandomOverSampler(random_state=42)
X_over, y_over = over_sampler.fit_resample(X, y)

df_over = pd.DataFrame(X_over, columns=X.columns)
df_over["Result"] = y_over

print("\nClass Distribution After Oversampling:\n", df_over["Result"].value_counts())
print("Shape Before:", df.shape)
print("Shape After:", df_over.shape)
print("\nOversampled Dataset:\n", df_over.head())

# Final comparison
print("\n========== FINAL COMPARISON ==========")
print("\nOriginal:\n", y.value_counts())
print("\nUndersampled:\n", y_under.value_counts())
print("\nOversampled:\n", y_over.value_counts())
print("\nOriginal Shape:", df.shape)
print("Undersampled Shape:", df_under.shape)
print("Oversampled Shape:", df_over.shape)

print("\n========== EXPERIMENT 9 COMPLETED ==========")
