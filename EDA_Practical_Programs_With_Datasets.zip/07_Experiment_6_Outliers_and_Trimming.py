import pandas as pd
import numpy as np

# Keep titanic.csv in the same folder as this program.
df = pd.read_csv("titanic.csv")

# Helper: IQR outlier detection
def detect_iqr(data, column):
    values = data[column].dropna()
    q1 = values.quantile(0.25)
    q3 = values.quantile(0.75)
    iqr = q3 - q1
    lower = q1 - 1.5 * iqr
    upper = q3 + 1.5 * iqr
    outliers = values[(values < lower) | (values > upper)]
    print(f"\n{column}:")
    print("Q1:", q1, "Q3:", q3, "IQR:", iqr)
    print("Lower Bound:", lower, "Upper Bound:", upper)
    print("Outlier Count:", len(outliers))
    return lower, upper, outliers

# Helper: Z-score (population standard deviation)
def calculate_zscore(series):
    return (series - series.mean()) / series.std(ddof=0)

# 6.1 Q1: IQR outliers in Age
print("\n6.1 IQR Q1: AGE")
detect_iqr(df, "Age")

# 6.1 Q2: Fare outlier percentage
print("\n6.1 IQR Q2: FARE OUTLIER PERCENTAGE")
low, high, fare_outliers = detect_iqr(df, "Fare")
print("Fare Outlier Percentage:", len(fare_outliers) / len(df) * 100, "%")

# 6.1 Q3: Distinct SibSp outlier values
print("\n6.1 IQR Q3: SIBSP")
_, _, sibsp_outliers = detect_iqr(df, "SibSp")
print("Distinct SibSp Outlier Values:", sorted(sibsp_outliers.unique()))

# 6.1 Z-score Q1: Age outlier count
print("\n6.1 Z-SCORE Q1: AGE")
age_z = calculate_zscore(df["Age"])
print("Age Outlier Count (|Z| > 3):", (age_z.abs() > 3).sum())

# 6.1 Z-score Q2: Top 5 Fare outliers
print("\n6.1 Z-SCORE Q2: FARE")
fare_z = calculate_zscore(df["Fare"])
fare_outlier_rows = df.loc[fare_z.abs() > 3, "Fare"]
print("Top 5 Fare Outliers:\n", fare_outlier_rows.sort_values(ascending=False).head(5))

# 6.1 Z-score Q3: SibSp and Parch outlier counts
print("\n6.1 Z-SCORE Q3: SIBSP AND PARCH")
sibsp_z = calculate_zscore(df["SibSp"])
parch_z = calculate_zscore(df["Parch"])
print("SibSp Outliers:", (sibsp_z.abs() > 3).sum())
print("Parch Outliers:", (parch_z.abs() > 3).sum())

# Helper: IQR trimming
def trim_iqr(data, column):
    values = data[column].dropna()
    q1 = values.quantile(0.25)
    q3 = values.quantile(0.75)
    iqr = q3 - q1
    lower = q1 - 1.5 * iqr
    upper = q3 + 1.5 * iqr
    return data[data[column].between(lower, upper) | data[column].isna()].copy()

# 6.2 IQR Q1: Trim Age
print("\n6.2 IQR Q1: TRIM AGE")
age_before = df["Age"].mean()
age_trimmed = trim_iqr(df, "Age")
age_after = age_trimmed["Age"].mean()
print("Mean Before:", age_before, "Mean After:", age_after)
print("Change in Mean (After - Before):", age_after - age_before)

# 6.2 IQR Q2: Trim Fare
print("\n6.2 IQR Q2: TRIM FARE")
fare_before = df["Fare"].median()
fare_trimmed = trim_iqr(df, "Fare")
fare_after = fare_trimmed["Fare"].median()
print("Median Before:", fare_before, "Median After:", fare_after)

# 6.2 IQR Q3: Trim SibSp
print("\n6.2 IQR Q3: TRIM SIBSP")
sibsp_trimmed = trim_iqr(df, "SibSp")
print("Unique Before:", sorted(df["SibSp"].dropna().unique()))
print("Unique After:", sorted(sibsp_trimmed["SibSp"].dropna().unique()))

# Helper: Z-score trimming
def trim_zscore(data, column):
    z = calculate_zscore(data[column])
    return data[(z.abs() <= 3) | z.isna()].copy()

# 6.2 Z-score Q1: Trim Age
print("\n6.2 Z-SCORE Q1: TRIM AGE")
age_before = df["Age"].mean()
age_trimmed_z = trim_zscore(df, "Age")
age_after = age_trimmed_z["Age"].mean()
print("Mean Before:", age_before, "Mean After:", age_after)
print("Change in Mean (After - Before):", age_after - age_before)

# 6.2 Z-score Q2: Trim Fare
print("\n6.2 Z-SCORE Q2: TRIM FARE")
fare_before = df["Fare"].median()
fare_trimmed_z = trim_zscore(df, "Fare")
fare_after = fare_trimmed_z["Fare"].median()
print("Median Before:", fare_before, "Median After:", fare_after)

# 6.2 Z-score Q3: Trim SibSp
print("\n6.2 Z-SCORE Q3: TRIM SIBSP")
sibsp_trimmed_z = trim_zscore(df, "SibSp")
print("Unique Before:", sorted(df["SibSp"].dropna().unique()))
print("Unique After:", sorted(sibsp_trimmed_z["SibSp"].dropna().unique()))

print("\n========== EXPERIMENT 6 COMPLETED ==========")
