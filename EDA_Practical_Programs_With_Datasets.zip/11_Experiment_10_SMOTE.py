import pandas as pd
from sklearn.datasets import make_classification
from imblearn.over_sampling import SMOTE

# Q1: Generate imbalanced dataset
X, y = make_classification(
    n_samples=1000,
    n_features=5,
    n_informative=3,
    n_redundant=1,
    n_classes=2,
    weights=[0.9, 0.1],
    random_state=42
)

columns = ["Feature1", "Feature2", "Feature3", "Feature4", "Feature5"]
df = pd.DataFrame(X, columns=columns)
df["Target"] = y

print("First 10 Rows:\n", df.head(10))
print("\nBasic Statistics:\n", df.describe())
print("\nOriginal Class Distribution:\n", df["Target"].value_counts())

# Q2: Separate features and target
X = df.drop("Target", axis=1)
y = df["Target"]

print("\nShape Before SMOTE:", df.shape)

# Apply SMOTE
smote = SMOTE(random_state=42)
X_resampled, y_resampled = smote.fit_resample(X, y)

# Convert resampled data into DataFrame
df_resampled = pd.DataFrame(X_resampled, columns=columns)
df_resampled["Target"] = y_resampled

print("\nClass Distribution After SMOTE:\n", df_resampled["Target"].value_counts())
print("\nShape After SMOTE:", df_resampled.shape)

# Final comparison
print("\n========== FINAL COMPARISON ==========")
print("\nBefore SMOTE:\n", df["Target"].value_counts())
print("\nAfter SMOTE:\n", df_resampled["Target"].value_counts())
print("\nOriginal Shape:", df.shape)
print("Resampled Shape:", df_resampled.shape)

print("\n========== EXPERIMENT 10 COMPLETED ==========")
