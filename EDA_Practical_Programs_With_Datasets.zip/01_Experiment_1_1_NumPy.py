import numpy as np

# Q1: NumPy version
print("NumPy Version:", np.__version__)

# Q2: Create arrays
arr1 = np.arange(1, 21)
arr2 = np.random.randint(10, 51, size=(4, 5))
identity = np.eye(6)

print("\n1D Array:\n", arr1)
print("\n2D Array:\n", arr2)
print("\n6x6 Identity Matrix:\n", identity)

# Q3: Array properties
print("\nShape:", arr2.shape)
print("Dimensions:", arr2.ndim)
print("Data Type:", arr2.dtype)
print("Total Elements:", arr2.size)

# Q4: Indexing
print("\nFirst Element of 1D Array:", arr1[0])
print("Last Element of 1D Array:", arr1[-1])
print("First Row:", arr2[0])
print("Last Row:", arr2[-1])
print("Second Row, Third Column:", arr2[1, 2])

# Q5: Slicing
print("\nFirst Three Elements:", arr1[:3])
print("Last Five Elements:", arr1[-5:])
print("First Two Rows:\n", arr2[:2])
print("Last Two Columns:\n", arr2[:, -2:])
print("Even Numbers:", arr1[arr1 % 2 == 0])

# Q6: Statistics
sales = np.array([250, 300, 400, 350, 500, 450, 600, 550])
print("\nSales:", sales)
print("Mean:", np.mean(sales))
print("Median:", np.median(sales))
print("Standard Deviation:", np.std(sales))
print("Variance:", np.var(sales))
print("Maximum:", np.max(sales))
print("Minimum:", np.min(sales))
print("Index of Maximum:", np.argmax(sales))
print("Index of Minimum:", np.argmin(sales))

# Q7: Conditional filtering
mean = np.mean(sales)
print("\nValues Greater Than Mean:", sales[sales > mean])
print("Values Between 300 and 500:", sales[(sales >= 300) & (sales <= 500)])

# Q8: Stacking and arithmetic
a = np.arange(1, 10).reshape(3, 3)
b = np.arange(10, 19).reshape(3, 3)
print("\nArray A:\n", a)
print("Array B:\n", b)
print("Vertical Stacking:\n", np.vstack((a, b)))
print("Horizontal Stacking:\n", np.hstack((a, b)))
print("Addition:\n", a + b)
print("Multiplication:\n", a * b)

# Q9: Missing values
data = np.array([23, 45, np.nan, 67, 89, np.nan, 34, 56])
print("\nMissing Value Mask:", np.isnan(data))
mean_value = np.nanmean(data)
print("Mean Excluding NaN:", mean_value)
data[np.isnan(data)] = mean_value
print("After Filling NaN:", data)

# Q10: Random age analysis
ages = np.random.randint(18, 61, size=100)
print("\nRandom Ages:", ages)
print("Average Age:", np.mean(ages))
print("Maximum Age:", np.max(ages))
print("Minimum Age:", np.min(ages))
print("People Above 40:", np.sum(ages > 40))
count = np.sum((ages >= 25) & (ages <= 35))
print("Percentage Between 25 and 35:", count / len(ages) * 100, "%")

# Q11: Temperature analysis
temp = np.array([29.5, 30.2, 31.8, 33.0, 32.5, 31.0, 29.8])
fahrenheit = temp * 9 / 5 + 32
print("\nCelsius:", temp)
print("Fahrenheit:", fahrenheit)
print("Hottest Day:", np.argmax(temp) + 1)
print("Coldest Day:", np.argmin(temp) + 1)
print("Average Temperature:", np.mean(temp))
