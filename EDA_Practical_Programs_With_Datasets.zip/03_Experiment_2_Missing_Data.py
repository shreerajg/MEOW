import pandas as pd

# Keep titanic.csv in the same folder as this program.
df = pd.read_csv("titanic.csv")

# Q1: Load dataset
print("First Five Rows:\n", df.head())

# Q2: Find missing values
missing = df.isnull().sum()
print("\nMissing Values in Each Column:\n", missing)
print("Total Missing Values:", missing.sum())
print("Column with Most Missing Values:", missing.idxmax())

# Q3: Fill Age with mean
df_mean = df.copy()
mean_age = df_mean["Age"].mean()
df_mean["Age"] = df_mean["Age"].fillna(mean_age)
print("\nMean Age:", mean_age)
print("Missing Age After Filling:", df_mean["Age"].isnull().sum())

# Q4: Fill Fare with median
df_median = df.copy()
median_fare = df_median["Fare"].median()
df_median["Fare"] = df_median["Fare"].fillna(median_fare)
print("\nMedian Fare:", median_fare)
print("Missing Fare After Filling:", df_median["Fare"].isnull().sum())

# Q5: Fill Embarked with mode
df_mode = df.copy()
mode_embarked = df_mode["Embarked"].mode()[0]
df_mode["Embarked"] = df_mode["Embarked"].fillna(mode_embarked)
print("\nMode of Embarked:", mode_embarked)
print("Missing Embarked After Filling:", df_mode["Embarked"].isnull().sum())

# Q6: Forward fill Age
df_ffill = df.copy()
df_ffill["Age"] = df_ffill["Age"].ffill()
print("\nForward Filled Age:\n", df_ffill["Age"].head(15))
print("Missing Age After Forward Fill:", df_ffill["Age"].isnull().sum())
print("Forward fill is useful when the previous observation is a reasonable replacement, e.g. ordered time-series data.")

# Q7: Backward fill Age
df_bfill = df.copy()
df_bfill["Age"] = df_bfill["Age"].bfill()
print("\nBackward Filled Age:\n", df_bfill["Age"].head(15))
print("Missing Age After Backward Fill:", df_bfill["Age"].isnull().sum())
print("Disadvantage: it uses a later observation to fill an earlier missing value.")

# Q8: Drop rows with missing Cabin
df_drop_rows = df.dropna(subset=["Cabin"])
print("\nShape Before Dropping Cabin-Missing Rows:", df.shape)
print("Shape After:", df_drop_rows.shape)

# Q9: Drop Cabin column
df_drop_column = df.drop(columns=["Cabin"])
print("\nColumns After Dropping Cabin:\n", df_drop_column.columns.tolist())
print("Is Cabin Present?", "Cabin" in df_drop_column.columns)

# Q10: Mixed cleaning
df_clean = df.copy()
df_clean["Age"] = df_clean["Age"].fillna(df_clean["Age"].mean())
df_clean["Embarked"] = df_clean["Embarked"].fillna(df_clean["Embarked"].mode()[0])
df_clean = df_clean.dropna(subset=["Cabin"])
print("\nFinal Dataset Shape:", df_clean.shape)
print("\nMissing Values After Cleaning:\n", df_clean.isnull().sum())
print("Total Remaining Missing Values:", df_clean.isnull().sum().sum())

# Numerical variables
print("\nNumerical Columns:", df.select_dtypes(include="number").columns.tolist())
print("\nNumerical Summary:\n", df.describe())
print("\nNumerical Means:\n", df.select_dtypes(include="number").mean())
print("\nNumerical Medians:\n", df.select_dtypes(include="number").median())
print("\nNumerical Standard Deviations:\n", df.select_dtypes(include="number").std())

# Categorical variables
cat_cols = df.select_dtypes(include="object").columns
print("\nCategorical Columns:", cat_cols.tolist())
print("\nCategorical Summary:\n", df.describe(include="object"))
for col in cat_cols:
    print(f"\nUnique values in {col}:\n", df[col].unique())
    print(f"Frequency counts for {col}:\n", df[col].value_counts(dropna=False))
