import pandas as pd

# Keep titanic.csv in the same folder as this program.
df = pd.read_csv("titanic.csv")

print("First 5 Rows:\n", df.head())

# Q1: Equal-width Age bins (4)
df["Age_Bin"] = pd.cut(df["Age"], bins=4)
print("\nQ1: Age Bins\n", df[["Age", "Age_Bin"]].head(10))
print("\nPassengers in Each Age Bin:\n", df["Age_Bin"].value_counts().sort_index())

# Q2: Equal-width Fare bins (5)
df["Fare_Bin"] = pd.cut(df["Fare"], bins=5)
print("\nQ2: Fare Bins\n", df[["Fare", "Fare_Bin"]].head(10))
print("\nPassengers in Each Fare Bin:\n", df["Fare_Bin"].value_counts().sort_index())
print("Fare Bin with Highest Count:", df["Fare_Bin"].value_counts().idxmax())

# Q3: Frequency binning Fare into 4 bins
df["Fare_Frequency_Bin"] = pd.qcut(df["Fare"], q=4, duplicates="drop")
print("\nQ3: Fare Frequency Bins\n", df[["Fare", "Fare_Frequency_Bin"]].head(10))
print("\nFare Bin Counts:\n", df["Fare_Frequency_Bin"].value_counts().sort_index())
print("\nApproximate Fare Ranges:\n",
      df.groupby("Fare_Frequency_Bin", observed=True)["Fare"].agg(["min", "max"]))

# Q4: Frequency binning Age into 3 equal-count groups
# qcut can encounter duplicate quantile boundaries; duplicates='drop' handles that,
# but labels are omitted so it remains valid if a boundary is duplicated.
df["Age_Group"] = pd.qcut(df["Age"], q=3, labels=["Young", "Middle", "Older"])
print("\nQ4: Age Groups\n", df[["Age", "Age_Group"]].head(10))
print("\nAge Group Counts:\n", df["Age_Group"].value_counts())
survival_rate = df.groupby("Age_Group", observed=True)["Survived"].mean()
print("\nSurvival Rate by Age Group:\n", survival_rate)
print("Age Group with Highest Survival Rate:", survival_rate.idxmax())

# Q5: Custom Age bins
df["Age_Category"] = pd.cut(
    df["Age"],
    bins=[-0.001, 12, 19, 59, float("inf")],
    labels=["Child", "Teen", "Adult", "Senior"]
)
print("\nQ5: Custom Age Categories\n", df[["Age", "Age_Category"]].head(10))
print("\nAge Category Counts:\n", df["Age_Category"].value_counts())
child_adult = df[df["Age_Category"].isin(["Child", "Adult"])]
survival = child_adult.groupby("Age_Category", observed=True)["Survived"].mean() * 100
print("\nChild vs Adult Survival Percentage:\n", survival)

# Q6: Custom Fare bins
df["Fare_Category"] = pd.cut(
    df["Fare"],
    bins=[-0.001, 50, 100, float("inf")],
    labels=["Low", "Medium", "High"]
)
print("\nQ6: Custom Fare Categories\n", df[["Fare", "Fare_Category"]].head(10))
print("\nFare Category Counts:\n", df["Fare_Category"].value_counts())
fare_survival = df.groupby("Fare_Category", observed=True)["Survived"].mean()
print("\nSurvival Probability by Fare Category:\n", fare_survival)
print("Fare Category with Highest Survival Probability:", fare_survival.idxmax())

print("\n========== EXPERIMENT 5 COMPLETED ==========")
