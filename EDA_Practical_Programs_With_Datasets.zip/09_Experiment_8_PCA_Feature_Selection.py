import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

from sklearn.datasets import load_breast_cancer, load_diabetes, load_iris
from sklearn.preprocessing import StandardScaler
from sklearn.decomposition import PCA
from sklearn.tree import DecisionTreeClassifier
from sklearn.feature_selection import SequentialFeatureSelector

# =====================================================
# EXPERIMENT 8.1: PCA
# =====================================================

# Q1: Breast Cancer PCA
print("\n8.1 Q1: BREAST CANCER PCA")
cancer = load_breast_cancer()
X_cancer = pd.DataFrame(cancer.data, columns=cancer.feature_names)
y_cancer = cancer.target

X_cancer_scaled = StandardScaler().fit_transform(X_cancer)
pca_cancer = PCA(n_components=2)
cancer_pca = pca_cancer.fit_transform(X_cancer_scaled)

cancer_df = pd.DataFrame(cancer_pca, columns=["PC1", "PC2"])
cancer_df["Target"] = y_cancer
print("\nFirst Five Rows:\n", cancer_df.head())
print("Explained Variance Ratio:", pca_cancer.explained_variance_ratio_)
print("Total Explained Variance:", pca_cancer.explained_variance_ratio_.sum())

plt.figure(figsize=(8, 5))
plt.scatter(cancer_pca[:, 0], cancer_pca[:, 1], c=y_cancer, cmap="viridis")
plt.xlabel("Principal Component 1")
plt.ylabel("Principal Component 2")
plt.title("PCA - Breast Cancer Dataset")
plt.colorbar(label="Target Class")
plt.show()

# Q2: Diabetes PCA
print("\n8.1 Q2: DIABETES PCA")
diabetes = load_diabetes()
X_diabetes = pd.DataFrame(diabetes.data, columns=diabetes.feature_names)
y_diabetes = diabetes.target

X_diabetes_scaled = StandardScaler().fit_transform(X_diabetes)
pca_diabetes = PCA(n_components=2)
diabetes_pca = pca_diabetes.fit_transform(X_diabetes_scaled)

diabetes_df = pd.DataFrame(diabetes_pca, columns=["PC1", "PC2"])
diabetes_df["Target"] = y_diabetes
print("\nFirst Five Rows:\n", diabetes_df.head())
print("Explained Variance Ratio:", pca_diabetes.explained_variance_ratio_)

plt.figure(figsize=(8, 5))
scatter = plt.scatter(diabetes_pca[:, 0], diabetes_pca[:, 1], c=y_diabetes, cmap="viridis")
plt.xlabel("Principal Component 1")
plt.ylabel("Principal Component 2")
plt.title("PCA - Diabetes Dataset")
plt.colorbar(scatter, label="Disease Progression Target")
plt.show()

# Q3: Correlation before and after PCA
print("\n8.1 Q3: CORRELATION")
print("\nOriginal Feature Correlation:\n", X_diabetes.corr().round(3))

pca_components = pd.DataFrame(diabetes_pca, columns=["PC1", "PC2"])
print("\nPCA Component Correlation:\n", pca_components.corr().round(3))

combined = pd.concat([X_diabetes.reset_index(drop=True), pca_components], axis=1)
print("\nOriginal Features vs PCA Components:\n",
      combined.corr().loc[X_diabetes.columns, ["PC1", "PC2"]].round(3))

# =====================================================
# EXPERIMENT 8.2: FEATURE SELECTION
# =====================================================

iris = load_iris()
X = pd.DataFrame(iris.data, columns=iris.feature_names)
y = iris.target

print("\n8.2: IRIS DATASET\n", X.head())

# Q1: Correlation filter method
print("\n8.2 Q1: CORRELATION")
corr = X.corrwith(pd.Series(y))
ranking = corr.abs().sort_values(ascending=False)
print("Feature Correlation:\n", corr)
print("\nSelected Features and Ranking:")
for rank, (feature, value) in enumerate(ranking.items(), start=1):
    print(rank, feature, "Correlation:", value)

# Q2: Sequential Backward Selection
print("\n8.2 Q2: BACKWARD SELECTION")
model = DecisionTreeClassifier(random_state=42)
sbs = SequentialFeatureSelector(model, n_features_to_select=2, direction="backward")
sbs.fit(X, y)
print("Selected Features:", list(X.columns[sbs.get_support()]))

# Q3: Sequential Forward Selection
print("\n8.2 Q3: FORWARD SELECTION")
sfs = SequentialFeatureSelector(model, n_features_to_select=2, direction="forward")
sfs.fit(X, y)
print("Selected Features:", list(X.columns[sfs.get_support()]))

# Q4: Decision Tree feature importance
print("\n8.2 Q4: FEATURE IMPORTANCE")
tree = DecisionTreeClassifier(random_state=42)
tree.fit(X, y)
importance = pd.Series(tree.feature_importances_, index=X.columns).sort_values(ascending=False)
print("Feature Importance Ranking:\n", importance)

plt.figure(figsize=(8, 5))
importance.plot(kind="bar")
plt.xlabel("Features")
plt.ylabel("Importance")
plt.title("Decision Tree Feature Importance")
plt.tight_layout()
plt.show()

print("\n========== EXPERIMENT 8 COMPLETED ==========")
