import pandas as pd
import numpy as np

# Keep titanic.csv in the same folder as this program.
df = pd.read_csv("titanic.csv")

# Q1-Q3: Version, loading, inspection
print("Pandas Version:", pd.__version__)
print("\nFirst Five Rows:\n", df.head())
print("\nShape:", df.shape)
print("\nColumns:", df.columns.tolist())
print("\nData Types:\n", df.dtypes)
print("\nDataset Information:")
df.info()

# Q4: Summary statistics
print("\nNumerical Statistics:\n", df.describe())
print("\nCategorical Statistics:\n", df.describe(include="object"))
print("\nAll Statistics:\n", df.describe(include="all"))

# Q5: Mean, median, mode
print("\nMean:\n", df[["Age", "Fare"]].mean())
print("\nMedian:\n", df[["Age", "Fare"]].median())
print("\nMode:\n", df[["Age", "Fare"]].mode())

# Q6: head, tail, loc, iloc
print("\nHead:\n", df.head())
print("\nTail:\n", df.tail())
print("\nloc[0]:\n", df.loc[0])
print("\niloc[0]:\n", df.iloc[0])

# Q7: Name and Age for first ten passengers
print("\nName and Age:\n", df[["Name", "Age"]].head(10))

# Q8: Conditional filtering
print("\nPassengers Older Than 50:\n", df[df["Age"] > 50])
print("\nFirst Class Survivors:\n", df[(df["Pclass"] == 1) & (df["Survived"] == 1)])

# Q9: Female, under 30, third class
print("\nFemale Under 30 in Third Class:\n",
      df[(df["Sex"] == "female") & (df["Age"] < 30) & (df["Pclass"] == 3)])

# Q10: Missing values
print("\nMissing Values:\n", df.isnull().sum())
clean = df.copy()
clean["Age"] = clean["Age"].fillna(clean["Age"].mean())
clean = clean.dropna(subset=["Embarked"])
print("\nMissing Values After Cleaning:\n", clean.isnull().sum())

# Q11: GroupBy
print("\nSurvival Rate by Class:\n", df.groupby("Pclass")["Survived"].mean())
print("\nAverage Age by Gender:\n", df.groupby("Sex")["Age"].mean())

# Q12: Highest fare and more than two siblings/spouses
print("\nHighest Fare Passenger:\n", df.loc[df["Fare"].idxmax()])
print("\nPassengers with SibSp > 2:\n", df[df["SibSp"] > 2])

# Q13: Mini EDA
print("\nAverage Fare:", df["Fare"].mean())
print("Average Age:", df["Age"].mean())
print("\nYoungest Passenger:\n", df.loc[df["Age"].idxmin(), ["Name", "Age"]])
print("\nOldest Passenger:\n", df.loc[df["Age"].idxmax(), ["Name", "Age"]])
print("Total Survivors:", df["Survived"].sum())
print("Male Passengers:", (df["Sex"] == "male").sum())
print("Female Passengers:", (df["Sex"] == "female").sum())
survival = df.groupby("Pclass")["Survived"].mean()
print("\nSurvival Rate by Class:\n", survival)
print("Class with Highest Survival Rate:", survival.idxmax())
print("\nEmbarked Counts:\n", df["Embarked"].value_counts())
print("Embarkation Point with Maximum Passengers:", df["Embarked"].value_counts().idxmax())

age_groups = pd.cut(df["Age"], bins=[0, 12, 18, 35, 60, np.inf],
                    labels=["Child", "Teen", "Young Adult", "Adult", "Senior"])
print("\nAge Group Counts:\n", age_groups.value_counts())
print("Age Group with Maximum Passengers:", age_groups.value_counts().idxmax())
