import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.preprocessing import StandardScaler, MinMaxScaler, RobustScaler

# Keep titanic.csv in the same folder as this program.
df = pd.read_csv("titanic.csv")

# Select Age and Fare; fill missing values for scaling.
data = df[["Age", "Fare"]].copy()
data["Age"] = data["Age"].fillna(data["Age"].mean())
data["Fare"] = data["Fare"].fillna(data["Fare"].median())

print("Original Data:\n", data.head())

# Q1: Standardization
standard_scaler = StandardScaler()
standard_scaled = standard_scaler.fit_transform(data)
standard_df = pd.DataFrame(standard_scaled, columns=["Age", "Fare"])
print("\nQ1: StandardScaler\n", standard_df.head())

# Q2: Min-Max normalization
minmax_scaler = MinMaxScaler()
minmax_scaled = minmax_scaler.fit_transform(data)
minmax_df = pd.DataFrame(minmax_scaled, columns=["Age", "Fare"])
print("\nQ2: MinMaxScaler\n", minmax_df.head())

# Q3: Robust scaling
robust_scaler = RobustScaler()
robust_scaled = robust_scaler.fit_transform(data)
robust_df = pd.DataFrame(robust_scaled, columns=["Age", "Fare"])
print("\nQ3: RobustScaler\n", robust_df.head())
print("\nRobust-scaled Age values > 2:\n", robust_df[robust_df["Age"] > 2])
print("\nRobust-scaled Fare values > 2:\n", robust_df[robust_df["Fare"] > 2])

# Q4: Histograms for Age
plt.figure(figsize=(12, 4))
plt.subplot(1, 3, 1)
plt.hist(standard_df["Age"], bins=20)
plt.title("StandardScaler - Age")
plt.xlabel("Scaled Age")
plt.ylabel("Frequency")

plt.subplot(1, 3, 2)
plt.hist(minmax_df["Age"], bins=20)
plt.title("MinMaxScaler - Age")
plt.xlabel("Scaled Age")

plt.subplot(1, 3, 3)
plt.hist(robust_df["Age"], bins=20)
plt.title("RobustScaler - Age")
plt.xlabel("Scaled Age")
plt.tight_layout()
plt.show()

# Q5: Manual standardization (population standard deviation, matching StandardScaler)
manual_standard = (data - data.mean()) / data.std(ddof=0)
print("\nQ5: Manual Standardization\n", manual_standard.head())

# Q6: Manual Min-Max normalization
manual_minmax = (data - data.min()) / (data.max() - data.min())
print("\nQ6: Manual Min-Max\n", manual_minmax.head())

# Q7: Manual robust scaling
q1 = data.quantile(0.25)
q3 = data.quantile(0.75)
iqr = q3 - q1
manual_robust = (data - data.median()) / iqr
print("\nQ7: Manual Robust Scaling\n", manual_robust.head())
print("\nPassengers with Manual Scaled Age > 2:\n", manual_robust[manual_robust["Age"] > 2])

# Q8: Compare manual and library outputs
print("\nQ8: Standardization Results Equal?")
print(np.allclose(standard_df.values, manual_standard.values))
print("\nMin-Max Results Equal?")
print(np.allclose(minmax_df.values, manual_minmax.values))

print("\n========== EXPERIMENT 7 COMPLETED ==========")
