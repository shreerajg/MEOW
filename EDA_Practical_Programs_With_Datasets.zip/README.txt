EDA Practical Programs

Files included:
01  Experiment 1.1 - NumPy
02  Experiment 1.2 - Pandas EDA
03  Experiment 2   - Missing Data
04  Experiment 3   - 3.1, 3.2 and 3.3 combined
05  Experiment 4   - Data Encoding
06  Experiment 5   - Binning
07  Experiment 6   - 6.1 and 6.2 combined
08  Experiment 7   - Feature Scaling
09  Experiment 8   - 8.1 and 8.2 combined
10  Experiment 9   - Data Balancing
11  Experiment 10  - SMOTE

Setup:
1. Install dependencies:
   pip install -r requirements.txt
2. Put titanic.csv in the same folder as the Titanic-based programs.
3. Put student_result.csv in the same folder as Experiment 9.
   It must contain columns: Maths, Physics, Chemistry, Result.
4. Run a program:
   python 01_Experiment_1_1_NumPy.py

Note:
- Experiment 3, 6, and 8 are each provided as one combined program,
  matching the combined practical coverage.
- Experiment 9 requires your college's Student Result Analysis CSV.
- Experiment 4 Q9 requires category_encoders.


DATASETS INCLUDED
-----------------
1. titanic.csv
   - 891 rows with Titanic-style passenger columns.
   - Includes missing values so missing-data and EDA programs can run.
   - IMPORTANT: This is a SYNTHETIC practice dataset generated to match the
     required Titanic column structure. It is not the original Kaggle Titanic
     passenger records.

2. student_result.csv
   - 240 sample student records.
   - Columns: Maths, Physics, Chemistry, Result.
   - Includes imbalanced Pass/Fail classes for Experiment 9.
   - This is synthetic sample data, not an official college dataset.

Keep both CSV files in the same folder as the Python scripts when running.
