import pandas as pd

# Keep titanic.csv in the same folder as this program.
df = pd.read_csv("titanic.csv")

# =====================================================
# EXPERIMENT 3.1: SORTING, RENAMING AND REPLACING
# =====================================================

print("\n3.1 Q1: First 5 Rows\n", df.head())

print("\n3.1 Q2: Age Ascending\n",
      df.sort_values("Age", ascending=True).head(10))

print("\n3.1 Q3: Fare Descending\n",
      df.sort_values("Fare", ascending=False).head(10))

print("\n3.1 Q4: Pclass Ascending, Fare Descending\n",
      df.sort_values(["Pclass", "Fare"], ascending=[True, False]).head(15))

df5 = df.rename(columns={"Pclass": "PassengerClass"})
print("\n3.1 Q5: Renamed Column\n", df5.columns.tolist())

df6 = df.rename(columns={
    "SibSp": "Siblings/Spouses Aboard",
    "Parch": "Parents/Children Aboard",
    "Fare": "Ticket Fare"
})
print("\n3.1 Q6: Multiple Renamed Columns\n", df6.columns.tolist())

df7 = df.copy()
df7["Sex"] = df7["Sex"].replace({"male": "M", "female": "F"})
print("\n3.1 Q7: Sex Replaced\n", df7["Sex"].head())

df8 = df.copy()
df8["Embarked"] = df8["Embarked"].replace({
    "S": "Southampton", "C": "Cherbourg", "Q": "Queenstown"
})
print("\n3.1 Q8: Embarked Replaced\n", df8["Embarked"].head())

df9 = df.copy()
df9["Pclass"] = df9["Pclass"].replace({
    1: "First Class", 2: "Second Class", 3: "Third Class"
})
print("\n3.1 Q9: Pclass Replaced\n", df9["Pclass"].head())

df10 = df.copy()
df10 = df10.rename(columns={"Age": "Passenger Age", "Fare": "Ticket Fare"})
df10["Sex"] = df10["Sex"].replace({"male": "M", "female": "F"})
df10["Pclass"] = df10["Pclass"].replace({
    1: "First Class", 2: "Second Class", 3: "Third Class"
})
df10 = df10.sort_values("Ticket Fare", ascending=False)
print("\n3.1 Q10: Combined Transformation\n", df10.head(10))

# =====================================================
# EXPERIMENT 3.2: SELECTION AND FILTERING
# =====================================================

print("\n3.2 Q1: First 5 Rows\n", df.head())
print("\n3.2 Q2: Name Column\n", df["Name"])
print("\n3.2 Q3: Selected Columns\n", df[["Name", "Sex", "Age", "Fare"]])
print("\n3.2 Q4: First 10 Rows\n", df.head(10))
print("\n3.2 Q5: Row at Index 50\n", df.loc[50])
print("\n3.2 Q6: Rows 100 to 110 Inclusive\n", df.loc[100:110])
print("\n3.2 Q7: Age > 50\n", df[df["Age"] > 50])
print("\n3.2 Q8: Female Passengers\n", df[df["Sex"] == "female"])
print("\n3.2 Q9: Fare > 100\n", df[df["Fare"] > 100])
print("\n3.2 Q10: Females in First Class\n",
      df[(df["Sex"] == "female") & (df["Pclass"] == 1)])
print("\n3.2 Q11: Males in Class 2 or 3\n",
      df[(df["Sex"] == "male") & (df["Pclass"].isin([2, 3]))])
result = df[(df["Age"] < 18) & (df["Fare"] > 50) & (df["Embarked"] == "S")]
print("\n3.2 Q12: Complex Filtering\n",
      result[["Name", "Age", "Fare", "Embarked"]])

# =====================================================
# EXPERIMENT 3.3: GROUPING AND AGGREGATION
# =====================================================

print("\n3.3 Q1: First 5 Rows\n", df.head())
print("\n3.3 Q2: Average Age by Sex\n", df.groupby("Sex")["Age"].mean())
print("\n3.3 Q3: Average Fare by Pclass\n", df.groupby("Pclass")["Fare"].mean())

print("\n3.3 Q4: Aggregations by Pclass\n",
      df.groupby("Pclass").agg(
          Average_Age=("Age", "mean"),
          Maximum_Fare=("Fare", "max"),
          Passenger_Count=("PassengerId", "count")
      ))

print("\n3.3 Q5: Average Fare by Embarked and Sex\n",
      df.groupby(["Embarked", "Sex"])["Fare"].mean())

print("\n3.3 Q6: Custom Aggregations\n",
      df.groupby("Pclass").agg({
          "Age": ["mean", "median"],
          "Fare": ["min", "max"]
      }))

print("\n3.3 Q7: Named Aggregations\n",
      df.groupby("Sex").agg(
          **{"Mean Age": ("Age", "mean"), "Highest Fare": ("Fare", "max")}
      ))

print("\n3.3 Q8: Mean Fare Sorted Descending\n",
      df.groupby("Pclass")["Fare"].mean().sort_values(ascending=False))

print("\n3.3 Q9: Passenger Count by Embarked\n",
      df.groupby("Embarked")["PassengerId"].count().sort_values(ascending=False))

print("\n3.3 Q10: Complex Grouping\n",
      df.groupby(["Pclass", "Sex"]).agg(
          Passenger_Count=("PassengerId", "count"),
          Average_Age=("Age", "mean"),
          Average_Fare=("Fare", "mean")
      ).sort_values("Average_Fare", ascending=False))

print("\n========== EXPERIMENT 3 COMPLETED ==========")
